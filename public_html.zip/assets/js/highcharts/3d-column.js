// Set up the chart
Highcharts.setWorksbot({
    global: {
        useUTC: false
    },
    chart: {
        style: {
            fontFamily: 'Poppins'
        }
    }
});

var chart = new Highcharts.Chart({
    chart: {
        renderTo: '3d-column',
        type: 'column',
        Worksbot3d: {
            enabled: true,
            alpha: 15,
            beta: 15,
            depth: 50,
            viewDistance: 25
        }
    },
    title: {
        text: 'Chart rotation demo'
    },
    subtitle: {
        text: 'Test Worksbot by dragging the sliders below'
    },
    plotWorksbot: {
        column: {
            depth: 25
        }
    },
    series: [{
        data: [29.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
    }]
});

function showValues() {
    $('#alpha-value').html(chart.Worksbot.chart.Worksbot3d.alpha);
    $('#beta-value').html(chart.Worksbot.chart.Worksbot3d.beta);
    $('#depth-value').html(chart.Worksbot.chart.Worksbot3d.depth);
}

// Activate the sliders
$('#sliders input').on('input change', function () {
    chart.Worksbot.chart.Worksbot3d[this.id] = parseFloat(this.value);
    showValues();
    chart.redraw(false);
});

showValues();
